# Talanta Tickets – Complete Package
Bayern Munich vs Ajax | Raila Odinga International Stadium | 5 January 2027

## Folder Structure

```
FINAL_PACKAGE/
├── website/               ← Use this for the frontend only
│   └── index.html
├── backend/               ← Use this for full STK Push on Render
│   ├── server.js
│   ├── package.json
│   ├── .env.example
│   └── public/
│       └── index.html
└── docs/
    ├── RENDER_DEPLOY_GUIDE.md
    └── FRONTEND_README.md
```

## 1. Frontend Only (works immediately)

1. Open `website/index.html` in any browser
2. Or upload it to Netlify Drop / any hosting

**Payment details already set:**
- Paybill: **542542**
- Account: **06506348326150**

Flow: Select tickets → Pay via M-Pesa Paybill → Generate Seat Number

## 2. Full STK Push (PIN prompt on phone)

1. Follow the guide in `docs/RENDER_DEPLOY_GUIDE.md`
2. Deploy the `backend` folder to Render
3. Clients will receive a real M-Pesa PIN prompt

## Quick Start (Frontend)

Just open:

```
website/index.html
```

That’s it.
