# Deploy Talanta Tickets on Render (STK Push)

Follow these steps carefully.

## 1. Create a GitHub repository

1. Go to https://github.com/new
2. Name it e.g. `talanta-tickets`
3. Create the repository (public or private)

## 2. Upload the backend folder

Upload **everything inside** the `mpesa-backend` folder to the root of your GitHub repo:

```
mpesa-backend/
  ├── server.js
  ├── package.json
  ├── public/
  │     └── index.html
  └── README.md
```

Easiest way:
- Download the zip
- Extract `mpesa-backend`
- Drag the files into your new GitHub repo (or use GitHub Desktop / git)

## 3. Create a Web Service on Render

1. Go to https://render.com and sign up / log in (free)
2. Click **New +** → **Web Service**
3. Connect your GitHub account and select the `talanta-tickets` repository
4. Fill in:

| Field | Value |
|-------|-------|
| Name | `talanta-tickets` (or any name) |
| Region | Choose closest (e.g. Frankfurt) |
| Branch | `main` |
| Runtime | **Node** |
| Build Command | `npm install` |
| Start Command | `npm start` |
| Instance Type | **Free** |

5. Click **Advanced** → **Add Environment Variable** and add these:

| Key | Value |
|-----|-------|
| `CONSUMER_KEY` | `nZZzd2bNW8oMXVigAdHx77S44hX0cxyIjvYACcCH1j5ExDGZ` |
| `CONSUMER_SECRET` | `v6lEK9o9kIYtm7h4LwPtx7EW5PqtMyVblTOUZSBGlBiR2AX0B5aKLKC4PMizI1eW` |
| `PASSKEY` | `bfb279f9aa9bdbcf158e97dd71a467cd2e0c893059b10f78e6b72ada1ed2c919` |
| `SHORTCODE` | `542542` |
| `ACCOUNT_REFERENCE` | `06506348326150` |
| `IS_SANDBOX` | `true` |

6. Click **Create Web Service**

## 4. Wait for deploy

Render will build and start the service (2–5 minutes).  
When it shows **Live**, copy your URL, for example:

```
https://talanta-tickets.onrender.com
```

## 5. Test the website

Open:

```
https://YOUR-APP-NAME.onrender.com
```

or

```
https://YOUR-APP-NAME.onrender.com/index.html
```

1. Add tickets to cart
2. Click **Pay with M-Pesa**
3. Enter a phone number
4. Click **Send M-Pesa Prompt**
5. Your phone should receive the STK Push

## Important notes

- **Sandbox mode** is currently enabled (`IS_SANDBOX=true`).  
  Sandbox only works with Safaricom test numbers. Real money will not move.

- To go **live** (real payments):
  1. Get production Consumer Key, Secret and Passkey from Daraja
  2. In Render → Environment, set `IS_SANDBOX` = `false`
  3. Update the three credential variables with production values
  4. Make sure Paybill 542542 is enabled for STK Push / Lipa Na M-Pesa Online

- Free Render services sleep after 15 minutes of inactivity.  
  First request after sleep can take 30–60 seconds.

## Callback URL

The server automatically uses:

```
https://YOUR-APP-NAME.onrender.com/api/mpesa/callback
```

No extra configuration needed.
