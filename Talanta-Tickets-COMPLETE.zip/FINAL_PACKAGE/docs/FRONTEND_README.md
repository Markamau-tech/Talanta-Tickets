# Talanta Tickets – Frontend

Complete ticket sales website for Bayern Munich vs Ajax  
Raila Odinga International Stadium – 5 January 2027

## What’s included

- Modern responsive design (works on phone & desktop)
- Ticket categories with cart
- M-Pesa payment flow
- Automatic Seat Number receipt after payment
- Mobile menu + logo

## How to use (3 options)

### Option A – Open directly (simplest)
1. Double-click `index.html`
2. It opens in your browser
3. Clients can select tickets and pay via Paybill 542542 / Account 06506348326150

### Option B – Host for free (recommended)
Upload `index.html` to any of these:

- **Netlify** → drag & drop the file at https://app.netlify.com/drop  
- **Vercel** → import the folder  
- **GitHub Pages**  
- Any web hosting (cPanel, Hostinger, etc.)

### Option C – Connect real STK Push
1. Deploy the backend on Render (see RENDER_DEPLOY_GUIDE.md)
2. Open `index.html` in a text editor
3. Find this line near the bottom:

```js
const API_BASE = '';
```

4. Change it to your Render URL:

```js
const API_BASE = 'https://your-app-name.onrender.com';
```

5. Save and re-upload the file

Now when a client clicks “Pay with M-Pesa” they will receive the PIN prompt on their phone.

## Payment details already set

- Paybill: **542542**
- Account: **06506348326150**

## Files

- `index.html` → the complete website (only file you need)
